package edu.rmit.cose2633.s3804132.Assignment2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Partitioner;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Task1bPairs {

	public static class PairsMapper extends Mapper<Object, Text, Text, DoubleWritable> {

		private final static DoubleWritable one = new DoubleWritable(1);
		private Text wordPair = new Text();

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			// Splitting each lines
			String line[] = value.toString().split("\n");
			String[] words = null;
			for (int k = 0; k < line.length; k++) {
				//Splitting the words to choose the word to find neighbour for it
				words = line[k].split(" ");
				if (words.length > 1 && words.length < 100) {
					// star and end to set the neighbour front and back of the word in the same line
					int start = 0;
					int end = 0;
					int neighbour = words.length - 1;
					String emitPair = "";
					for (int i = 0; i < words.length; i++) {
						if (i - neighbour < 0) {
							start = 0;
						} else {
							start = i - neighbour;
						}

						if (i + neighbour >= words.length) {
							end = words.length - 1;
						} else {
							end = i + neighbour;
						}
						emitPair = "";
						for (int j = start; j <= end; j++) {

							if (i == j) {
								continue;
							} else {
								emitPair = words[i] + "," + words[j];
							}
							context.write(new Text(emitPair), one);
							//emitting word,* pair to calculate the total count 
							String spWord = words[i] + "," + "*";
							context.write(new Text(spWord), one);
						}
					}
				}
			}
		}

	}

	public static class Task1bPairsPartitioner extends Partitioner<Text, DoubleWritable> {
		@Override
		public int getPartition(Text key, DoubleWritable value, int numReduceTasks) {
			String word[] = key.toString().split(",");
			int val = 0;
			if (word.length < 1) {

			} else {
				val = Math.abs(word[0].hashCode() % numReduceTasks);
			}
			return val;
		}
	}

	public static class PairsReducer extends Reducer<Text, DoubleWritable, Text, DoubleWritable> {
		private Text currentWord = new Text("gggg");
		private DoubleWritable count = new DoubleWritable();
		private DoubleWritable rf = new DoubleWritable();

		public void reduce(Text key, Iterable<DoubleWritable> values, Context context)
				throws IOException, InterruptedException {
			String[] reducerKey = key.toString().split(",");
			if (reducerKey.length > 1) {
				// calculating the total wrds based on the *
				if (reducerKey[1].equals("*")) {
					if (reducerKey[1].equals(currentWord)) {
						count.set(count.get() + getTotalCount(values));
					} else {
						currentWord.set(reducerKey[0]);
						count.set(0.0);
						count.set(getTotalCount(values));
					}
				} else {
					// calculating total frequency
					double totalCount = getTotalCount(values);
					rf.set((double) totalCount / count.get());
					context.write(key, rf);
				}

			}
		}

		public static double getTotalCount(Iterable<DoubleWritable> values) {

			double sum = 0;
			for (DoubleWritable val : values) {
				sum += val.get();
			}
			return sum;

		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "TaskA");
		job.setJarByClass(Task1bPairs.class);
		job.setMapperClass(PairsMapper.class);
//		job.setCombinerClass(PairsReducer.class);
		job.setPartitionerClass(Task1bPairsPartitioner.class);
		job.setReducerClass(PairsReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(DoubleWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
