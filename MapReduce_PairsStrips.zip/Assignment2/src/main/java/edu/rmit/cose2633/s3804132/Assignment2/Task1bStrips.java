package edu.rmit.cose2633.s3804132.Assignment2;

import java.io.IOException;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Task1bStrips {

	public static class Task1bStripsMapper extends Mapper<LongWritable, Text, Text, MapWritable> {
		private MapWritable associateMap = new MapWritable();
		private Text word = new Text();

		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			// Splitting each lines
			String[] lines = value.toString().split("\n");
			for (int w = 0; w < lines.length; w++) {
				//Splitting the words to choose the word to find neighbour for it
				String words[] = lines[w].split(" ");
				int neighbors = words.length - 1;
				if (words.length > 1 && words.length < 100) {
					for (int i = 0; i < words.length; i++) {
						word.set(words[i]);
						associateMap.clear();
						// star and end to set the neighbour front and back of the word in the same line
						int start = (i - neighbors < 0) ? 0 : i - neighbors;
						int end = (i + neighbors >= words.length) ? words.length - 1 : i + neighbors;
						for (int j = start; j <= end; j++) {
							if (j == i)
								continue;
							Text neighbor = new Text(words[j]);
							if (associateMap.containsKey(neighbor)) {
								DoubleWritable count = (DoubleWritable) associateMap.get(neighbor);
								count.set(count.get() + 1);
								associateMap.put(neighbor, count);
							} else {
								associateMap.put(neighbor, new DoubleWritable(1));
							}
						}
						context.write(word, associateMap);
					}
				}
			}
		}
	}

	public static class Task1bStripsReducer extends Reducer<Text, MapWritable, Text, MapWritable> {
		private MapWritable reducerMap = new MapWritable();

		public void reduce(Text key, Iterable<MapWritable> values, Context context)
				throws IOException, InterruptedException {
			reducerMap.clear();
			for (MapWritable neighbourSet : values) {
				// getting the key and looping it to calculate the total count of the word.
				Set<Writable> keySet = neighbourSet.keySet();
				for (Writable keys : keySet) {
					DoubleWritable intialCount = (DoubleWritable) neighbourSet.get(keys);
					if (reducerMap.containsKey(keys)) {
						DoubleWritable newCount = (DoubleWritable) reducerMap.get(keys);
						newCount.set(newCount.get() + intialCount.get());
						reducerMap.put(keys, newCount);
					} else {
						reducerMap.put(keys, intialCount);
					}
				}
			}
			// finding the total count of the neighbouring word for the main word.
			DoubleWritable total = new DoubleWritable();
			Set<Writable> keys = reducerMap.keySet();
			for (Writable k : keys) {
				DoubleWritable reducedCount = (DoubleWritable) reducerMap.get(k);
				total.set(total.get() + reducedCount.get());
			}
			
			// finding the relative frequency for each neighbour for the key word.
			for (Writable k : keys) {
				DoubleWritable freqCount = (DoubleWritable) reducerMap.get(k);
				DoubleWritable div = new DoubleWritable();
				div.set(freqCount.get() / total.get());
				reducerMap.put(k, div);
			}
			context.write(key, reducerMap);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Task1bStrips");

		job.setJarByClass(Task1bStrips.class);
		job.setMapperClass(Task1bStripsMapper.class);
		job.setCombinerClass(Task1bStripsReducer.class);
		job.setReducerClass(Task1bStripsReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(MapWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
