package edu.rmit.cose2633.s3804132.Assignment2;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Task1aPairs {

	public static class PairsMapper extends Mapper<Object, Text, Text, IntWritable> {

		private final static IntWritable one = new IntWritable(1);

		public void map(Object key, Text value, Context context) throws IOException, InterruptedException {
			// Splitting each lines
			String line[] = value.toString().split("\n");
			String[] words = null;
			for (int k = 0; k < line.length; k++) {
				//Splitting the words to choose the word to find neighbour for it
				words = line[k].split(" ");
				if (words.length > 1 && words.length < 100) {
					// star and end to set the neighbour front and back of the word in the same line
					int start = 0;
					int end = 0;
					int neighbour = words.length - 1;
					String emitPair = "";
					for (int i = 0; i < words.length; i++) {
						if (i - neighbour < 0) {
							start = 0;
						} else {
							start = i - neighbour;
						}

						if (i + neighbour >= words.length) {
							end = words.length - 1;
						} else {
							end = i + neighbour;
						}
						emitPair = "";
						for (int j = start; j <= end; j++) {

							if (i == j) {
								continue;
							} else {
								emitPair = words[i] + " " + words[j];
							}
							context.write(new Text(emitPair), one);
						}
					}
				}
			}
		}

	}

	public static class PairsReducer extends Reducer<Text, IntWritable, Text, IntWritable> {
		private IntWritable result = new IntWritable();

		public void reduce(Text key, Iterable<IntWritable> values, Context context)
				throws IOException, InterruptedException {
			int sum = 0;
// aggregating the count to save it in the file
			for (IntWritable val : values) {
				sum += val.get();
			}
			result.set(sum);
			context.write(key, result);
		}

	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Task1aPairs");

		job.setJarByClass(Task1aPairs.class);
		job.setMapperClass(PairsMapper.class);
		job.setCombinerClass(PairsReducer.class);
		job.setReducerClass(PairsReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(IntWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
