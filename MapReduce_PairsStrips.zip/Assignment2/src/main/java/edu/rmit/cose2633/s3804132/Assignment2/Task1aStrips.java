package edu.rmit.cose2633.s3804132.Assignment2;

import java.io.IOException;
import java.util.Set;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.MapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.mapred.JobHistory.Keys;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class Task1aStrips {

	public static class Task1aStripsMapper extends Mapper<LongWritable, Text, Text, MapWritable> {
		private MapWritable associateMap = new MapWritable();
		private Text word = new Text();

		protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
			// Splitting each lines
			String[] lines = value.toString().split("\n");
			for (int w = 0; w < lines.length; w++) {
				//Splitting the words to choose the word to find neighbour for it
				String words[] = lines[w].split(" ");
				int neighbors = words.length - 1;
				if (words.length > 1 && words.length < 100) {
					for (int i = 0; i < words.length; i++) {
						word.set(words[i]);
						associateMap.clear();
						// star and end to set the neighbour front and back of the word in the same line
						int start = (i - neighbors < 0) ? 0 : i - neighbors;
						int end = (i + neighbors >= words.length) ? words.length - 1 : i + neighbors;
						for (int j = start; j <= end; j++) {
							if (j == i)
								continue;
							Text neighbor = new Text(words[j]);
							if (associateMap.containsKey(neighbor)) {
								// creating a map to add neighbour,value pair for the key word
								IntWritable count = (IntWritable) associateMap.get(neighbor);
								count.set(count.get() + 1);
								associateMap.put(neighbor, count);
							} else {
								associateMap.put(neighbor, new IntWritable(1));
							}
						}
						context.write(word, associateMap);
					}
				}
			}
		}
	}

	public static class Task1aReducer extends Reducer<Text, MapWritable, Text, MapWritable> {
		private MapWritable reducerMap = new MapWritable();

		protected void reduce(Text key, Iterable<MapWritable> values, Context context)
				throws IOException, InterruptedException {
			reducerMap.clear();
			for (MapWritable neighbourSet : values) {
		// getting the key and looping it to calculate the total count of the word.
				Set<Writable> keys = neighbourSet.keySet();
				for (Writable keyset : keys) {
					IntWritable fromCount = (IntWritable) neighbourSet.get(keyset);
					if (reducerMap.containsKey(keyset)) {
						IntWritable count = (IntWritable) reducerMap.get(keyset);
						count.set(count.get() + fromCount.get());
						reducerMap.put(keyset, count);
					} else {
						reducerMap.put(keyset, fromCount);
					}
				}
			}
			context.write(key, reducerMap);
		}
	}

	public static void main(String[] args) throws Exception {
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "TaskaStrips");

		job.setJarByClass(Task1aStrips.class);
		job.setMapperClass(Task1aStripsMapper.class);
		job.setCombinerClass(Task1aReducer.class);
		job.setReducerClass(Task1aReducer.class);
		job.setOutputKeyClass(Text.class);
		job.setOutputValueClass(MapWritable.class);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
