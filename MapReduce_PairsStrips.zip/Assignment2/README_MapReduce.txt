									   BIG DATA PROCESSING
										SEMESTER 2
       									       ASSIGNMENT 2

									Gowtham Raghavendran
										s3804132


The Maven project contains the source code files to perform Task 1: Compute Co-occurrence Matrix 
The jar file of the built maven project is in the target folder. 

After connecting to the Amazon EC2 Linux server, and creating the cluster using the ./create_cluster.sh command, the EMR cluster will be created.
A link to the HDFS - http://s3804132.hue.cosc2637.route53.aws.rmit.edu.au:8888 and the Master node of the cluster -
ssh hadoop@s3804132.emr.cosc2637.route53.aws.rmit.edu.au -i s3804132-cosc2637.pem

Drag and drop the jar file into the Hue GUI - create with username s3804132 to enable direct copy pasting the following commands.
Create a new folder called input and drag and drop the 3 input files into this directory. 

After uploading the jar and the input files, in the PuTTy terminal, copy the jar file in the HDFS into the jumphost of the Master node of the EMR cluster using:
hadoop fs -copyToLocal /user/s3804132/Task1Jar.jar

In the next step you can run the task class and get the output using the following commands:
For Task 1.1 Pairs-
hadoop jar Task1Jar.jar edu.rmit.cose2633.s3804132.Assignment2.Task1aPairs /user/s3804132/input /user/s3804132/output1aPairs
For Task 1.1 Strips-
hadoop jar Task1Jar.jar edu.rmit.cose2633.s3804132.Assignment2.Task1aStrips /user/s3804132/input /user/s3804132/output1aStrips
For Task 1.2 Pairs-
hadoop jar Task1Jar.jar edu.rmit.cose2633.s3804132.Assignment2.Task1bPairs /user/s3804132/input /user/s3804132/output1bPairs
For Task 1.2 Strips-
hadoop jar Task1Jar.jar edu.rmit.cose2633.s3804132.Assignment2.Task1bStrips /user/s3804132/input /user/s3804132/output1bStrips

You can check the output files under the name output[1a/1b Pairs/Strips]


To analyse the effect of the number of nodes on the performance of the EMR clusters, Task 1 is used to process a large dataset in the S3 commoncrawl.
The effect of increasing the number of clusters from 3,5,7 is given below:
We can boost the cluster by using the ./boost_cluster command and then running the cluster.

Task 1.1 Pairs
No. of clusters	 Mapper	CPU_MILLISECONDS	 Reducer CPU_MILLISECONDS	Total CPU_MILLISECONDS
3		 1560320			 262880				1823300
5		 1570760			 265720				1846430		
7		 1558070		         268190				1826260

It is seen that there is a fluctuation when changin the number of nodes in the  cluster.Inividually it is seen that for this approach c nodes cluster is best suited
as the time taken to compelte is faster than when using 5 and 7 nodes.


Task 1.1 Strips
No. of Node	 Mapper	CPU_MILLISECONDS	 Reducer CPU_MILLISECONDS	Total CPU_MILLISECONDS
3		 3166630			 4911550			8078180
5		 3265430		         5603960			8869350
7		 3098920			 4897920			7996840		 

In this approach when we use 7 node cluster the over all time is reduced a bit when compared to the 3 and 5 node cluster.
even the map and the reduce execution time is comparatively lower for the cluster which has 7 nodes.

Task 1.2 Pairs
No. of Nodes	 Mapper	CPU_MILLISECONDS	 Reducer CPU_MILLISECONDS	Total CPU_MILLISECONDS
3		 2954700			 1040130			3994830
5		 2940440			 1098240			4038680
7		 2974660		         1082440			4057950		

For finding the relative frequency using the pairs approach we can see that the cluster with 3 nodes perform better than the clusters with 5 and 7 nodes.
Although the difference in time not huge 3 node cluster might be prefered for this approach.


Task1.2 Strips
No. of Nodes	 Mapper	CPU_MILLISECONDS	 Reducer CPU_MILLISECONDS	Total CPU_MILLISECONDS
3		 4203680			 8493660			12697340
5		 4223640			 7616140			11839780
7		 4181250			 9235670			13425820		

In this case, 5 node cluster provides promising execution time. Lower time than the other two cluster allows us to choose the cluster with 5 nodes.


The above execution time might change based on the system performance and the cluster performance in AWS. The above time are approximately same 
when executed in any system and cluster.



